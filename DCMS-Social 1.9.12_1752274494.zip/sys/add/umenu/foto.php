<?





echo "<img src='/style/my_menu/foto.png' alt='' /> <a href='/foto/$user[id]/'>Фотоальбомы</a><br />\n";





?>
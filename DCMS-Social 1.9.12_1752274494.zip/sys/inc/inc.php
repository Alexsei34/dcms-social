<?
include_once 'sys/inc/home.php';
include_once 'sys/inc/start.php';

include_once SESS;
include_once HOME;
include_once SETTINGS;;
include_once COMPRESS;;
include_once DB_CONNECT;;
include_once IPUA;
include_once FNC;
include_once SHIF;
include_once USER;;

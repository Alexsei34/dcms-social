<?
require_once $_SERVER['DOCUMENT_ROOT']."/sys/inc/start.php";




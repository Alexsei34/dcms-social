<?
require_once $_SERVER['DOCUMENT_ROOT']."/sys/inc/home.php";




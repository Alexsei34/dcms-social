<?
if (isset($_SESSION['message'])){echo "<div class='msg'>$_SESSION[message]</div>";$_SESSION['message']=NULL;}
?>
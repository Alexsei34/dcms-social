<?
include_once 'sys/inc/home.php'; 
include_once H.'sys/inc/start.php';
include_once COMPRESS;
include_once SESS;
include_once SETTINGS;
include_once DB_CONNECT;
include_once IPUA;
include_once FNC;
include_once USER;
only_reg();


$set['title'] = 'История входов';

include_once THEAD;
title();
aut();


$k_post = dbresult(dbquery("SELECT COUNT(*) FROM `user_log` WHERE `id_user` = '$user[id]'"),0);

$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];

echo '<table class="post">';

if (empty($k_post))
{
	 echo '<div class="mess">';
	 echo 'Нет записаных авторизаций';
	 echo '</div>';
}	 

$q = dbquery("SELECT * FROM `user_log` WHERE `id_user` = '".$user['id']."' ORDER BY `id` DESC  LIMIT $start, $set[p_str]");

while ($post = dbassoc($q))
{
	
	$ank = dbarray(dbquery("SELECT * FROM `user` WHERE `id` = '$user[id]' LIMIT 1"));

	// Лесенка
	echo '<div class="' . ($num % 2 ? "nav1" : "nav2") . '">';
	$num++;

	echo '<img src="/style/my_menu/logout_16.png" alt="" />';



	if ($post['method'] != 1)
		echo ' Автовход<br />';
	else
		echo ' Ввод логина и пароля (' . vremja($post['time']) . ')<br />';

			
	echo 'IP: ' . long2ip($post['ip']) . '<br />';
	echo 'Браузер: ' . output_text($post['ua']);
	echo '</div>';
}

echo '</table>';

// Вывод страниц
if ($k_page > 1)str("?",$k_page,$page);  

echo '<div class="foot">';
echo '<img src="/style/icons/str.gif" alt="*" /> <a href="/info.php">Моя cтраница</a><br />';
echo '<img src="/style/icons/str.gif" alt="*" /> <a href="/umenu.php">Мое меню</a><br />';
echo '</div>';

include_once TFOOT;
?>
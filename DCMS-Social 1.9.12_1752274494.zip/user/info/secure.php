<?



include_once '../../sys/inc/start.php';



include_once COMPRESS;



include_once SESS;



include_once '../../sys/inc/home.php';



include_once SETTINGS;



include_once DB_CONNECT;



include_once IPUA;



include_once FNC;



include_once SHIF;



include_once USER;







only_reg();



$set['title']='Безопасность';



include_once THEAD;



title();



if (isset($_POST['save'])){







if (isset($_POST['pass']) && dbresult(dbquery("SELECT COUNT(*) FROM `user` WHERE `id` = $user[id] AND `pass` = '".shif($_POST['pass'])."' LIMIT 1"), 0)==1)



{



if (isset($_POST['pass1']) && isset($_POST['pass2']))



{



if ($_POST['pass1']==$_POST['pass2'])



{



if (strlen2($_POST['pass1'])<6)$err='По соображениям безопасности новый пароль не может быть короче 6-ти символов';



if (strlen2($_POST['pass1'])>32)$err='Длина пароля превышает 32 символа';



}



else $err='Новый пароль не совпадает с подтверждением';



}



else $err='Введите новый пароль';



}



else $err='Старый пароль неверен';















if (!isset($err))



{



dbquery("UPDATE `user` SET `pass` = '".shif($_POST['pass1'])."' WHERE `id` = '$user[id]' LIMIT 1");



setcookie('pass', cookie_encrypt($_POST['pass1'],$user['id']), time()+60*60*24*365);



$_SESSION['message'] = 'Пароль успешно изменен';



header("Location: ?");



exit;



}







}



err();



aut();











echo "<div id='comments' class='menus'>";







echo "<div class='webmenu'>";



echo "<a href='/user/info/settings.php'>Общие</a>";



echo "</div>"; 







echo "<div class='webmenu last'>";



echo "<a href='/user/tape/settings.php'>Лента</a>";



echo "</div>"; 







echo "<div class='webmenu last'>";



echo "<a href='/user/discussions/settings.php'>Обсуждения</a>";



echo "</div>"; 







echo "<div class='webmenu last'>";



echo "<a href='/user/notification/settings.php'>Уведомления</a>";



echo "</div>"; 











echo "<div class='webmenu last'>";



echo "<a href='/user/info/settings.privacy.php' >Приватность</a>";



echo "</div>"; 







echo "<div class='webmenu last'>";



echo "<a href='/user/info/secure.php'  class='activ'>Пароль</a>";



echo "</div>"; 







echo "</div>";







echo "<form method='post' action='?$passgen'>\n";







echo "Старый пароль:<br />\n<input type='text' name='pass' value='' /><br />\n";



echo "Новый пароль:<br />\n<input type='password' name='pass1' value='' /><br />\n";



echo "Подтверждение:<br />\n<input type='password' name='pass2' value='' /><br />\n";



echo "<input type='submit' name='save' value='Изменить' />\n";



echo "</form>\n";











include_once TFOOT;



?>